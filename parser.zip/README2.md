# NOC Port Monitor - Chrome Extension

Summary
NOC Port Monitor je MV3 Chrome ekstenzija koja automatizuje pracenje stanja portova na routerima u NOC Portalu (nocportal.telekom.rs). Ekstenzija periodicno izvrsava JSON-RPC pozive ka Odoo backendu, preuzima logove sa komandi "action_log", filtrira samo dogadjaje promene stanja (UP/DOWN) i prikazuje ih u popup UI-ju kao listu routera sa agregiranim portovima i hronologijom dogadjaja. Osnovni tok rada je: detekcija autentifikacije i session_id preko content script-a, pozivi u background service worker-u, parsiranje i grupisanje logova, cuvanje rezultata u chrome.storage i render u popup-u. Scheduler (chrome.alarms) omogucava automatske skenove na 1h/2h/3h/6h, dok manualni scan radi za sve ili pojedinacni router. Konfiguracija routera i API endpointa je centralizovana u `config.js`, pa se projekat lako prilagodjava drugim lokacijama ili dodatnim uredjajima. UI prikazuje status indikatore (green/red/gray), broj pogodjenih portova, metadata o routeru i listu dogadjaja sa timestampovima. Projekat je namenjen NOC timu za brzu detekciju regresija/prekida bez rucnog kopiranja logova.

## Features
- Scheduler sa periodama 1h/2h/3h/6h
- Manualni scan svih ili pojedinacnog routera
- Detekcija UP/DOWN eventa uz timestamp
- Status indikatori i accordion prikaz po routeru
- Auto-detekcija login stanja i session cookie

## Arhitektura
- `manifest.json` - MV3 manifest
- `background.js` - service worker (scheduler, API pozivi, parsiranje, storage)
- `content.js` - detekcija auth stanja i session_id na NOC Portalu
- `app.html`, `app.css`, `app.js` - popup UI (scheduler, scan, accordion)
- `config.js` - routeri, endpointi, regex/patterni, storage kljucevi
- `parser.js` - log parsing i grupisanje (shared utils)
- `api.js` - pomocne funkcije za payload i validaciju (trenutno nije vezano u workflow)
- `dom.js`, `router.js`, `session.js`, `settings.js`, `storage.js` - UI/utility moduli (korisni za prosirenja ili future UI)

## Kako radi (data flow)
1. `content.js` prati DOM na `nocportal.telekom.rs` i salje `session_id` i auth status u `background.js`.
2. `background.js` cuva session u `chrome.storage.local` i upravlja scheduler-om.
3. Scan ciklus:
   - Create wizard (`/web/dataset/call_kw/.../create`)
   - action_log (`/web/dataset/call_button`)
   - read output (`/web/dataset/call_kw/.../read`)
4. `background.js` filtrira logove i detektuje UP/DOWN evente prema `INTERFACE_STATE_PATTERNS`.
5. Rezultati se cuvaju u `chrome.storage.local` i popup renderuje stanje.

## Instalacija
1. Otvori `chrome://extensions/`
2. Ukljuci **Developer mode**
3. Klikni **Load unpacked**
4. Izaberi folder `parser/`

## Koriscenje
1. Uloguj se na `https://nocportal.telekom.rs`
2. Otvori ekstenziju
3. Ukljuci Scheduler ili pokreni manualni scan
4. Pregledaj accordion listu i dogadjaje po portu

## Konfiguracija
Podesavanja su u `config.js`:
- `API_BASE`, `API_ENDPOINTS`
- `UID`
- `ROUTERS` (lista uredjaja)
- `INTERFACE_STATE_PATTERNS` (UP/DOWN filter)
- `FREQUENCY_MAP` (scheduler)

## Skladistenje podataka
State se cuva u `chrome.storage.local`:
- `schedulerEnabled`, `schedulerFrequency`
- `sessionId`, `authState`
- `routerData`, `lastScan`

Format `routerData`:
```js
{
  [routerId]: {
    ports: { [portId]: [{ state, timestamp, date, raw }] },
    affectedPorts: number,
    hasIssues: boolean,
    lastUpdated: number
  }
}
```

## API endpointi
| Korak | Endpoint |
| --- | --- |
| Create wizard | `/web/dataset/call_kw/mts.router.switch.command.wizard/create` |
| action_log | `/web/dataset/call_button` |
| Read output | `/web/dataset/call_kw/mts.router.switch.command.wizard/read` |

## Dozvole
- `storage` - persitencija state-a
- `alarms` - scheduler
- `cookies` - session auto-detekcija
- `host_permissions` - pristup NOC Portalu

## Troubleshooting
- "Session cannot be auto-detected": uveri se da si ulogovan na NOC Portal i da postoji `session_id` cookie.
- "No session available": content script nije poslao session (ponovo ucitaj portal ili ekstenziju).
- Prazni logovi: proveri `INTERFACE_STATE_PATTERNS` i dozvole.

## Version
`2.0.0`
